import React from 'react';
export default function HomePage() {
  return <div className="p-6 text-center">GuardXChain - Coming Soon</div>;
}